/*
 * Copyright 2010-2022 Gildas Lormeau
 * contact : gildas.lormeau <at> gmail.com
 * 
 * This file is part of SingleFile.
 *
 *   The code in this file is free software: you can redistribute it and/or 
 *   modify it under the terms of the GNU Affero General Public License 
 *   (GNU AGPL) as published by the Free Software Foundation, either version 3
 *   of the License, or (at your option) any later version.
 * 
 *   The code in this file is distributed in the hope that it will be useful, 
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of 
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero 
 *   General Public License for more details.
 *
 *   As additional permission under GNU AGPL version 3 section 7, you may 
 *   distribute UNMODIFIED VERSIONS OF THIS file without the copy of the GNU 
 *   AGPL normally required by section 4, provided you include this license 
 *   notice and a URL through which recipients can access the Corresponding 
 *   Source.
 */

import * as processors from "./processors/index.js";
import * as vendor from "./vendor/index.js";
import * as modules from "./modules/index.js";
import * as core from "./core/index.js";
import * as helper from "./core/helper.js";
import * as util from "./core/util.js";

let SingleFile;

export {
	init,
	getPageData,
	processors,
	vendor,
	modules,
	helper,
	SingleFile
};

function init(initOptions) {
	if (typeof SingleFile == "undefined") {
		SingleFile = core.getClass(util.getInstance(initOptions));
	}
}

async function getPageData(options = {}, initOptions, doc, win) {
	options = helper.normalizeOptions(options);
	if (doc === undefined) {
		doc = globalThis.document;
	}
	if (win === undefined) {
		win = globalThis;
	}
	const frames = processors.frameTree;
	let framesSessionId;
	init(initOptions);
	if (doc && win) {
		helper.initDoc(doc);
		const preInitializationPromises = [];
		if (!options.saveRawPage) {
			let lazyLoadPromise;
			if (options.loadDeferredContent) {
				lazyLoadPromise = processors.lazy.process(options);
				if (options.loadDeferredContentBeforeFrames) {
					await lazyLoadPromise;
				}
			}
			if (!options.removeFrames && frames && globalThis.frames) {
				let frameTreePromise;
				if (options.loadDeferredContent) {
					frameTreePromise = new Promise(resolve => globalThis.setTimeout(() => resolve(frames.getAsync(options)), options.loadDeferredContentBeforeFrames || !options.loadDeferredContent ? 0 : options.loadDeferredContentMaxIdleTime));
				} else {
					frameTreePromise = frames.getAsync(options);
				}
				if (options.loadDeferredContentBeforeFrames) {
					options.frames = await frameTreePromise;
				} else {
					preInitializationPromises.push(frameTreePromise);
				}
			}
			if (options.loadDeferredContent && !options.loadDeferredContentBeforeFrames) {
				preInitializationPromises.push(lazyLoadPromise);
			}
		}
		if (!options.loadDeferredContentBeforeFrames) {
			[options.frames] = await Promise.all(preInitializationPromises);
		}
		framesSessionId = options.frames && options.frames.sessionId;
	}
	options.doc = doc;
	options.win = win;
	options.insertCanonicalLink = options.insertCanonicalLink === undefined ? true : options.insertCanonicalLink;

	const externalOnProgress = options.onprogress;
	options.onprogress = async event => {
		if (event.type === event.RESOURCES_INITIALIZED && doc && win && options.loadDeferredContent) {
			processors.lazy.resetZoomLevel(options);
		}

		if (externalOnProgress) {
			await externalOnProgress(event);
		}
	};

	const processor = new SingleFile(options);
	await processor.run();
	if (framesSessionId) {
		frames.cleanup(framesSessionId);
	}
	const pageData = await processor.getPageData();
	if (options.compressContent) {
		const compressionOptions = {};
		for (const optionName of processors.compression.PROCESS_OPTION_NAMES) {
			compressionOptions[optionName] = options[optionName];
		}
		const blob = await processors.compression.process(pageData, compressionOptions);
		delete pageData.resources;
		let arrayBuffer;
		if (globalThis.FileReader) {
			const reader = new globalThis.FileReader();
			reader.readAsArrayBuffer(blob);
			arrayBuffer = await new Promise((resolve, reject) => {
				reader.addEventListener("load", () => resolve(reader.result), false);
				reader.addEventListener("error", reject, false);
			});
		} else {
			arrayBuffer = await blob.arrayBuffer();
		}
		pageData.content = Array.from(new Uint8Array(arrayBuffer));
		if (options.addProof) {
			pageData.hash = await helper.digest("SHA-256", new Uint8Array(arrayBuffer));
		}
	}
	if (pageData.manifest) {
		const content = options.compressContent ? new Uint8Array(pageData.content) : pageData.content;
		pageData.manifest.output = {
			filename: pageData.filename,
			mimeType: pageData.mimeType,
			size: options.compressContent ? content.length : helper.getContentSize(content),
			sha256: await helper.digest("SHA-256", content)
		};
	}
	return pageData;
}