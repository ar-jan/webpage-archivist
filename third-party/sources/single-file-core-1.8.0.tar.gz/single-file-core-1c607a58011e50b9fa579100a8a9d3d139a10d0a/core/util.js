/*
 * Copyright 2010-2022 Gildas Lormeau
 * contact : gildas.lormeau <at> gmail.com
 * 
 * This file is part of SingleFile.
 *
 *   The code in this file is free software: you can redistribute it and/or 
 *   modify it under the terms of the GNU Affero General Public License 
 *   (GNU AGPL) as published by the Free Software Foundation, either version 3
 *   of the License, or (at your option) any later version.
 * 
 *   The code in this file is distributed in the hope that it will be useful, 
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of 
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero 
 *   General Public License for more details.
 *
 *   As additional permission under GNU AGPL version 3 section 7, you may 
 *   distribute UNMODIFIED VERSIONS OF THIS file without the copy of the GNU 
 *   AGPL normally required by section 4, provided you include this license 
 *   notice and a URL through which recipients can access the Corresponding 
 *   Source.
 */

import * as vendor from "./../vendor/index.js";
import * as modules from "./../modules/index.js";
import * as helper from "./helper.js";
import { getDoctypeString } from "./lib/doctype.js";

const DEBUG = false;
const ONE_MB = 1024 * 1024;
const PREFIX_CONTENT_TYPE_TEXT = "text/";
const CONTENT_TYPE_EXTENSIONS = {
	"image/svg+xml": ".svg",
	"image/png": ".png",
	"image/gif": ".gif",
	"image/tiff": ".tiff",
	"image/bmp": ".bmp",
	"image/x-icon": ".ico",
	"image/heif": ".heif",
	"image/heic": ".heic",
	"image/avif": ".avif",
	"image/jxl": ".jxl",
	"image/apng": ".apng",
	"image/jpeg": ".jpg",
	"image/webp": ".webp",
	"audio/mpeg": ".mp3",
	"audio/ogg": ".ogg",
	"audio/wav": ".wav",
	"audio/webm": ".webm",
	"video/3gpp": ".3gp",
	"video/3gpp2": ".3g2",
	"video/mpeg": ".mpeg",
	"video/quicktime": ".mov",
	"video/x-msvideo": ".avi",
	"video/webm": ".webm",
	"video/ogg": ".ogv",
	"video/mp4": ".mp4",
	"video/mp2t": ".ts",
	"font/otf": ".otf",
	"font/ttf": ".ttf",
	"font/woff": ".woff",
	"font/woff2": ".woff2",
	"application/vnd.ms-fontobject": ".eot",
	"font/collection": ".ttc"
};
const CONTENT_TYPE_OCTET_STREAM = "application/octet-stream";
const TRANSPORT_STREAM_SYNC_BYTE = 71;
const TRANSPORT_STREAM_PACKET_SIZE = 188;
const ZIP_FILENAME_LENGTH_OFFSET = 26;
const ZIP_FILENAME_OFFSET = 30;
const USD_FILENAME_REGEXP = /\.usd[ac]?$/i;
const CONTENT_TYPES_HTML = ["text/html", "application/xhtml+xml"];
const EXPECTED_TYPES_MEDIA = ["font", "image", "video", "audio", "model"];
const EXPECTED_TYPE_IMAGE = "image";
const EXPECTED_TYPE_DOCUMENT = "document";
const DATA_URI_PREFIX = "data:";
const MANIFEST_OUTCOME_EMBEDDED = "embedded";
const MANIFEST_OUTCOME_FAILED = "failed";
const MANIFEST_OUTCOME_BLOCKED = "blocked";
const MANIFEST_OUTCOME_REJECTED = "rejected";
const MANIFEST_OUTCOME_OVERSIZED = "oversized";
const MANIFEST_FETCHED_BY_PAGE = "page";
const MANIFEST_FETCHED_BY_FRAME = "frame";
const MANIFEST_HEADER_NAMES = ["date", "last-modified", "etag", "content-length", "content-encoding", "cache-control", "age", "expires", "server"];
const MIN_SERVER_ERROR_STATUS = 500;

const URL = globalThis.URL;
const DOMParser = globalThis.DOMParser;
const Blob = globalThis.Blob;
const TextDecoder = globalThis.TextDecoder;
const URLSearchParams = globalThis.URLSearchParams;

export {
	getInstance
};

function getInstance(utilOptions) {
	utilOptions = utilOptions || {};
	utilOptions.fetch = utilOptions.fetch || ((url, options) => globalThis.fetch(url, { ...options, cache: options.cache || "force-cache", referrerPolicy: "strict-origin-when-cross-origin" }));
	utilOptions.frameFetch = utilOptions.frameFetch || utilOptions.fetch;
	return {
		getDoctypeString,
		brotli: utilOptions.brotli,
		getFilenameExtension(resourceURL, replacedCharacters, replacementCharacter, replacementCharacters) {
			let matchExtension;
			try {
				matchExtension = new URL(resourceURL).pathname.match(/(\.[^\\/.]*)$/);
				// eslint-disable-next-line no-unused-vars
			} catch (error) {
				// ignored
			}
			return ((matchExtension && matchExtension[1] && this.getValidFilename(matchExtension[1], replacedCharacters, replacementCharacter, replacementCharacters)) || "").toLowerCase();
		},
		getContentTypeExtension(contentType) {
			return CONTENT_TYPE_EXTENSIONS[contentType] || "";
		},
		getContent,
		parseURL(resourceURL, baseURI) {
			if (baseURI === undefined) {
				return new URL(resourceURL);
			} else {
				return new URL(resourceURL, baseURI);
			}
		},
		resolveURL(resourceURL, baseURI) {
			return this.parseURL(resourceURL, baseURI).href;
		},
		getSearchParams(searchParams) {
			return Array.from(new URLSearchParams(searchParams));
		},
		getValidFilename(filename, replacedCharacters, replacementCharacter, replacementCharacters) {
			return helper.getValidFilename(filename, replacedCharacters, replacementCharacter, replacementCharacters);
		},
		parseDocContent(content, baseURI) {
			return helper.parseDocContent(content, baseURI);
		},
		parseXMLContent(content) {
			return (new DOMParser()).parseFromString(content, "text/xml");
		},
		parseSVGContent(content) {
			const doc = (new DOMParser()).parseFromString(content, "image/svg+xml");
			if (doc.querySelector("parsererror")) {
				return (new DOMParser()).parseFromString(content, "text/html");
			} else {
				return doc;
			}
		},
		fixInvalidNesting(doc, preventCleanup = true, options) {
			helper.fixInvalidNesting(doc, helper.NESTING_TRACK_ID_ATTRIBUTE_NAME, preventCleanup, options);
		},
		removeNestingMarkers(doc) {
			helper.removeNestingMarkers(doc);
		},
		getNestingMarkerData(element) {
			return helper.getNestingMarkerData(element);
		},
		markInvalidNesting(doc) {
			helper.markInvalidNesting(doc, helper.NESTING_TRACK_ID_ATTRIBUTE_NAME);
		},
		getFixInvalidNestingSource() {
			return helper.fixInvalidNesting.toString().replace(/\s+/g, " ");
		},
		async digest(algo, text) {
			return helper.digest(algo, text);
		},
		getContentSize(content) {
			return helper.getContentSize(content);
		},
		formatFilename(content, doc, options) {
			return modules.templateFormatter.formatFilename(content, doc, options);
		},
		getMimeType(options) {
			return !options.compressContent || options.selfExtractingArchive ? "text/html" : "application/zip";
		},
		async evalTemplate(template, options, content, doc, context) {
			return modules.templateFormatter.evalTemplate(template, options, content, doc, context);
		},
		minifyHTML(doc, options) {
			return modules.htmlMinifier.process(doc, options);
		},
		minifyCSSRules(doc, stylesheets, styles) {
			return modules.cssRulesMinifier.process(doc, stylesheets, styles);
		},
		removeUnusedFonts(doc, stylesheets, styles, options) {
			return modules.fontsMinifier.process(doc, stylesheets, styles, options);
		},
		minifyMedias(stylesheets, options) {
			return modules.mediasAltMinifier.process(stylesheets, options);
		},
		removeAlternativeImages(doc) {
			return modules.imagesAltMinifier.process(doc);
		},
		parseSrcset(srcset) {
			return vendor.srcsetParser.process(srcset);
		},
		preProcessDoc(doc, win, options) {
			return helper.preProcessDoc(doc, win, options);
		},
		postProcessDoc(doc, markedElements, invalidElements) {
			helper.postProcessDoc(doc, markedElements, invalidElements);
		},
		serialize(doc, compressHTML, omittedEndTagElements) {
			return modules.serializer.process(doc, compressHTML, omittedEndTagElements);
		},
		removeQuotes(string) {
			return helper.removeQuotes(string);
		},
		appendInfobar(doc, options) {
			return helper.appendInfobar(doc, options);
		},
		findLast(array, callback) {
			if (array.findLast && typeof array.findLast == "function") {
				return array.findLast(callback);
			} else {
				let index = array.length;
				while (index--) {
					if (callback(array[index], index, array)) {
						return array[index];
					}
				}
			}
		},
		ON_BEFORE_CAPTURE_EVENT_NAME: helper.ON_BEFORE_CAPTURE_EVENT_NAME,
		ON_AFTER_CAPTURE_EVENT_NAME: helper.ON_AFTER_CAPTURE_EVENT_NAME,
		WIN_ID_ATTRIBUTE_NAME: helper.WIN_ID_ATTRIBUTE_NAME,
		REMOVED_CONTENT_ATTRIBUTE_NAME: helper.REMOVED_CONTENT_ATTRIBUTE_NAME,
		HIDDEN_CONTENT_ATTRIBUTE_NAME: helper.HIDDEN_CONTENT_ATTRIBUTE_NAME,
		HIDDEN_FRAME_ATTRIBUTE_NAME: helper.HIDDEN_FRAME_ATTRIBUTE_NAME,
		IMAGE_ATTRIBUTE_NAME: helper.IMAGE_ATTRIBUTE_NAME,
		POSTER_ATTRIBUTE_NAME: helper.POSTER_ATTRIBUTE_NAME,
		VIDEO_ATTRIBUTE_NAME: helper.VIDEO_ATTRIBUTE_NAME,
		CANVAS_ATTRIBUTE_NAME: helper.CANVAS_ATTRIBUTE_NAME,
		STYLE_ATTRIBUTE_NAME: helper.STYLE_ATTRIBUTE_NAME,
		INPUT_VALUE_ATTRIBUTE_NAME: helper.INPUT_VALUE_ATTRIBUTE_NAME,
		INPUT_CHECKED_ATTRIBUTE_NAME: helper.INPUT_CHECKED_ATTRIBUTE_NAME,
		SHADOW_ROOT_ATTRIBUTE_NAME: helper.SHADOW_ROOT_ATTRIBUTE_NAME,
		SLOT_ATTRIBUTE_NAME: helper.SLOT_ATTRIBUTE_NAME,
		ASSIGNED_SLOT_ATTRIBUTE_NAME: helper.ASSIGNED_SLOT_ATTRIBUTE_NAME,
		ASSIGNED_SLOT_SEPARATOR: helper.ASSIGNED_SLOT_SEPARATOR,
		PRESERVED_SPACE_ELEMENT_ATTRIBUTE_NAME: helper.PRESERVED_SPACE_ELEMENT_ATTRIBUTE_NAME,
		STYLESHEET_ATTRIBUTE_NAME: helper.STYLESHEET_ATTRIBUTE_NAME,
		LINK_STYLESHEET_ATTRIBUTE_NAME: helper.LINK_STYLESHEET_ATTRIBUTE_NAME,
		CUSTOM_STYLESHEET_ATTRIBUTE_NAME: helper.CUSTOM_STYLESHEET_ATTRIBUTE_NAME,
		SELECTED_CONTENT_ATTRIBUTE_NAME: helper.SELECTED_CONTENT_ATTRIBUTE_NAME,
		INVALID_ELEMENT_ATTRIBUTE_NAME: helper.INVALID_ELEMENT_ATTRIBUTE_NAME,
		COMMENT_HEADER: helper.COMMENT_HEADER,
		COMMENT_HEADER_LEGACY: helper.COMMENT_HEADER_LEGACY,
		SINGLE_FILE_UI_ELEMENT_CLASS: helper.SINGLE_FILE_UI_ELEMENT_CLASS,
		EMPTY_RESOURCE: helper.EMPTY_RESOURCE,
		INFOBAR_TAGNAME: helper.INFOBAR_TAGNAME,
		WAIT_FOR_USERSCRIPT_PROPERTY_NAME: helper.WAIT_FOR_USERSCRIPT_PROPERTY_NAME,
		NO_SCRIPT_PROPERTY_NAME: helper.NO_SCRIPT_PROPERTY_NAME,
		NESTING_TRACK_ID_ATTRIBUTE_NAME: helper.NESTING_TRACK_ID_ATTRIBUTE_NAME,
		NESTING_START_MARKER: helper.NESTING_START_MARKER,
		NESTING_END_MARKER: helper.NESTING_END_MARKER,
		NESTING_RECREATED_ATTRIBUTE_NAME: helper.NESTING_RECREATED_ATTRIBUTE_NAME,
		getPosterDataURI: helper.getPosterDataURI
	};

	async function getContent(resourceURL, options) {
		const entry = options.manifestEntries && !resourceURL.startsWith(DATA_URI_PREFIX) ? { url: resourceURL, role: options.expectedType || EXPECTED_TYPE_DOCUMENT, outcome: MANIFEST_OUTCOME_FAILED } : undefined;
		const content = await fetchContent(resourceURL, options, entry);
		if (entry) {
			options.manifestEntries.push(entry);
			content.manifestEntry = entry;
		}
		return content;
	}

	async function fetchContent(resourceURL, options, entry) {
		let response, startTime, networkTimeoutId, networkTimeoutPromise, resolveNetworkTimeoutPromise;
		const fetchResource = utilOptions.fetch;
		const fetchFrameResource = utilOptions.frameFetch;
		if (DEBUG) {
			startTime = Date.now();
			log("  // STARTED download url =", resourceURL, "asBinary =", options.asBinary);
		}
		if (options.blockMixedContent && /^https:/i.test(options.baseURI) && !/^https:/i.test(resourceURL) && !/^blob:https:/i.test(resourceURL)) {
			setManifestOutcome(entry, MANIFEST_OUTCOME_BLOCKED);
			return getFetchResponse(resourceURL, options);
		}
		if (options.networkTimeout) {
			networkTimeoutPromise = new Promise((resolve, reject) => {
				resolveNetworkTimeoutPromise = resolve;
				networkTimeoutId = globalThis.setTimeout(() => reject(new Error("network timeout")), options.networkTimeout);
			});
		} else {
			networkTimeoutPromise = new Promise(resolve => {
				resolveNetworkTimeoutPromise = resolve;
			});
		}
		const fetchWithRetry = async (fetchFunction, fetchOptions) => {
			let response = await Promise.race([fetchFunction(resourceURL, fetchOptions), networkTimeoutPromise]);
			if (response.status >= MIN_SERVER_ERROR_STATUS) {
				try {
					response = await Promise.race([fetchFunction(resourceURL, { ...fetchOptions, cache: "reload" }), networkTimeoutPromise]);
					// eslint-disable-next-line no-unused-vars
				} catch (error) {
					// the stored error stands when the network cannot do better
				}
			}
			return response;
		};
		try {
			const accept =(options.acceptHeaders && options.acceptHeaders[options.expectedType]) || "*/*";
			const fetchOptions = { referrer: options.resourceReferrer, referrerPolicy: options.referrerPolicy || undefined, stylesheetURL: options.stylesheetURL || undefined, stylesheetReferrerPolicy: options.stylesheetReferrerPolicy || undefined, headers: { accept } };
			if (options.frameId) {
				try {
					response = await fetchWithRetry(fetchFrameResource, { frameId: options.frameId, ...fetchOptions });
					setManifestResponse(entry, response, MANIFEST_FETCHED_BY_FRAME);
					// eslint-disable-next-line no-unused-vars
				} catch (error) {
					response = await fetchWithRetry(fetchResource, fetchOptions);
					setManifestResponse(entry, response, MANIFEST_FETCHED_BY_PAGE);
				}
			} else {
				response = await fetchWithRetry(fetchResource, fetchOptions);
				setManifestResponse(entry, response, MANIFEST_FETCHED_BY_PAGE);
			}
		} catch (error) {
			setManifestError(entry, error);
			return getFailedFetchResponse(resourceURL, options);
		} finally {
			resolveNetworkTimeoutPromise();
			if (options.networkTimeout) {
				globalThis.clearTimeout(networkTimeoutId);
			}
		}
		let buffer;
		try {
			buffer = await response.arrayBuffer();
		} catch (error) {
			setManifestError(entry, error);
			return options.inline ? { data: options.asBinary ? helper.EMPTY_RESOURCE : "", resourceURL } : { resourceURL };
		}
		await setManifestContent(entry, buffer);
		resourceURL = response.url || resourceURL;
		let contentType = "", charset;
		try {
			const mimeType = new vendor.MIMEType(response.headers.get("content-type"));
			contentType = mimeType.type + "/" + mimeType.subtype;
			charset = mimeType.parameters.get("charset");
			// eslint-disable-next-line no-unused-vars
		} catch (error) {
			// ignored
		}
		const guessedContentType = guessMIMEType(options.expectedType, buffer);
		if (guessedContentType) {
			contentType = guessedContentType;
		} else if (!contentType || (contentType == CONTENT_TYPE_OCTET_STREAM && options.asBinary)) {
			contentType = options.contentType ? options.contentType : options.asBinary ? CONTENT_TYPE_OCTET_STREAM : "";
		}
		if (!charset && options.charset) {
			charset = options.charset;
		}
		if (entry) {
			entry.contentType = contentType;
			if (charset) {
				entry.charset = charset;
			}
		}
		if (options.asBinary) {
			if ((response.status >= 400 && options.expectedType != EXPECTED_TYPE_IMAGE) || (EXPECTED_TYPES_MEDIA.includes(options.expectedType) && CONTENT_TYPES_HTML.includes(contentType))) {
				setManifestOutcome(entry, MANIFEST_OUTCOME_REJECTED);
				return getFetchResponse(resourceURL, options);
			}
			try {
				if (DEBUG) {
					log("  // ENDED   download url =", resourceURL, "delay =", Date.now() - startTime);
				}
				if (options.maxResourceSizeEnabled && buffer.byteLength > options.maxResourceSize * ONE_MB) {
					setManifestOutcome(entry, MANIFEST_OUTCOME_OVERSIZED);
					return getFetchResponse(resourceURL, options);
				} else {
					setManifestOutcome(entry, MANIFEST_OUTCOME_EMBEDDED);
					return getFetchResponse(resourceURL, options, buffer, null, contentType);
				}
			} catch (error) {
				setManifestError(entry, error);
				return getFetchResponse(resourceURL, options);
			}
		} else {
			if (response.status >= 400 && options.expectedType != EXPECTED_TYPE_DOCUMENT) {
				setManifestOutcome(entry, MANIFEST_OUTCOME_REJECTED);
				return getFailedFetchResponse(resourceURL, options);
			}
			if (options.validateTextContentType && contentType && !contentType.startsWith(PREFIX_CONTENT_TYPE_TEXT)) {
				setManifestOutcome(entry, MANIFEST_OUTCOME_REJECTED);
				return getFetchResponse(resourceURL, options);
			}
			if (!charset) {
				charset = "utf-8";
			}
			if (DEBUG) {
				log("  // ENDED   download url =", resourceURL, "delay =", Date.now() - startTime);
			}
			if (options.maxResourceSizeEnabled && buffer.byteLength > options.maxResourceSize * ONE_MB) {
				setManifestOutcome(entry, MANIFEST_OUTCOME_OVERSIZED);
				return getFetchResponse(resourceURL, options, null, charset);
			} else {
				try {
					const fetchResponse = await getFetchResponse(resourceURL, options, buffer, charset, contentType);
					fetchResponse.referrerPolicy = (response.headers && response.headers.get("referrer-policy")) || undefined;
					setManifestOutcome(entry, MANIFEST_OUTCOME_EMBEDDED);
					return fetchResponse;
				} catch (error) {
					setManifestError(entry, error);
					return getFetchResponse(resourceURL, options, null, charset);
				}
			}
		}
	}
}

function setManifestResponse(entry, response, fetchedBy) {
	if (entry) {
		entry.fetchedBy = fetchedBy;
		if (response.url) {
			entry.finalUrl = response.url;
		}
		if (response.status !== undefined) {
			entry.status = response.status;
		}
		const headers = {};
		MANIFEST_HEADER_NAMES.forEach(name => {
			const value = getHeaderValue(response.headers, name);
			if (value) {
				headers[name] = value;
			}
		});
		if (Object.keys(headers).length) {
			entry.headers = headers;
		}
	}
}

function getHeaderValue(headers, name) {
	if (headers) {
		if (typeof headers.get == "function") {
			return headers.get(name);
		}
		const key = Object.keys(headers).find(key => key.toLowerCase() == name);
		return key === undefined ? undefined : headers[key];
	}
}

async function setManifestContent(entry, buffer) {
	if (entry) {
		entry.size = buffer.byteLength;
		entry.sha256 = await helper.digest("SHA-256", buffer);
	}
}

function setManifestOutcome(entry, outcome) {
	if (entry) {
		entry.outcome = outcome;
	}
}

function setManifestError(entry, error) {
	if (entry) {
		entry.outcome = MANIFEST_OUTCOME_FAILED;
		if (error && error.message) {
			entry.error = error.message;
		}
	}
}

async function getFailedFetchResponse(resourceURL, options) {
	const response = await getFetchResponse(resourceURL, options);
	response.failed = true;
	return response;
}

async function getFetchResponse(resourceURL, options, data, charset, contentType) {
	if (data) {
		if (options.asBinary) {
			if (options.inline) {
				data = await helper.getDataURI(new Blob([data], { type: contentType + (options.charset ? ";charset=" + options.charset : "") }));
			} else {
				data = new Uint8Array(data);
			}
		} else {
			const firstBytes = new Uint8Array(data.slice(0, 4));
			if (firstBytes[0] == 132 && firstBytes[1] == 49 && firstBytes[2] == 149 && firstBytes[3] == 51) {
				charset = "gb18030";
			} else if (firstBytes[0] == 255 && firstBytes[1] == 254) {
				charset = "utf-16le";
			} else if (firstBytes[0] == 254 && firstBytes[1] == 255) {
				charset = "utf-16be";
			}
			try {
				data = new TextDecoder(charset).decode(data);
				// eslint-disable-next-line no-unused-vars
			} catch (error) {
				charset = "utf-8";
				data = new TextDecoder(charset).decode(data);
			}
			data = data.replace(/^\ufeff/, "");
		}
	} else if (options.inline) {
		data = options.asBinary ? helper.EMPTY_RESOURCE : "";
	}
	return { data, resourceURL, charset, contentType };
}

function guessMIMEType(expectedType, buffer) {
	if (expectedType == "image") {
		if (compareBytes([255, 255, 255, 255], [0, 0, 1, 0])) {
			return "image/x-icon";
		}
		if (compareBytes([255, 255, 255, 255], [0, 0, 2, 0])) {
			return "image/x-icon";
		}
		if (compareBytes([255, 255], [66, 77])) {
			return "image/bmp";
		}
		if (compareBytes([255, 255, 255, 255, 255, 255], [71, 73, 70, 56, 57, 97])) {
			return "image/gif";
		}
		if (compareBytes([255, 255, 255, 255, 255, 255], [71, 73, 70, 56, 55, 97])) {
			return "image/gif";
		}
		if (compareBytes([255, 255, 255, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255], [82, 73, 70, 70, 0, 0, 0, 0, 87, 69, 66, 80, 86, 80])) {
			return "image/webp";
		}
		if (compareBytes([255, 255, 255, 255, 255, 255, 255, 255], [137, 80, 78, 71, 13, 10, 26, 10])) {
			return "image/png";
		}
		if (compareBytes([255, 255, 255], [255, 216, 255])) {
			return "image/jpeg";
		}
		if (compareBytes([0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 102, 116, 121, 112, 97, 118, 105, 102]) ||
			compareBytes([0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 102, 116, 121, 112, 97, 118, 105, 115])) {
			return "image/avif";
		}
		if (compareBytes([0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 102, 116, 121, 112, 104, 101, 105, 99]) ||
			compareBytes([0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 102, 116, 121, 112, 104, 101, 105, 120]) ||
			compareBytes([0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 102, 116, 121, 112, 104, 101, 118, 99]) ||
			compareBytes([0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 102, 116, 121, 112, 104, 101, 118, 120])) {
			return "image/heic";
		}
		if (compareBytes([255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255], [0, 0, 0, 12, 74, 88, 76, 32, 13, 10, 135, 10]) ||
			compareBytes([255, 255], [255, 10])) {
			return "image/jxl";
		}
		if (compareBytes([255, 255, 255, 255], [73, 73, 42, 0]) ||
			compareBytes([255, 255, 255, 255], [77, 77, 0, 42])) {
			return "image/tiff";
		}
	}
	if (expectedType == "font") {
		if (compareBytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255],
			[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 80])) {
			return "application/vnd.ms-fontobject";
		}
		if (compareBytes([255, 255, 255, 255], [0, 1, 0, 0])) {
			return "font/ttf";
		}
		if (compareBytes([255, 255, 255, 255], [79, 84, 84, 79])) {
			return "font/otf";
		}
		if (compareBytes([255, 255, 255, 255], [116, 116, 99, 102])) {
			return "font/collection";
		}
		if (compareBytes([255, 255, 255, 255], [119, 79, 70, 70])) {
			return "font/woff";
		}
		if (compareBytes([255, 255, 255, 255], [119, 79, 70, 50])) {
			return "font/woff2";
		}
	}
	if (expectedType == "video") {
		if (compareBytes([0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 102, 116, 121, 112, 105, 115, 111, 109])) {
			return "video/mp4";
		}
		if (compareBytes([255, 255, 255, 255, 0, 0, 0, 0, 255, 255, 255, 255], [82, 73, 70, 70, 0, 0, 0, 0, 65, 86, 73, 32])) {
			return "video/x-msvideo";
		}
		if (compareBytes([255, 255, 255, 255], [0, 0, 1, 179]) || compareBytes([255, 255, 255, 255], [0, 0, 1, 186])) {
			return "video/mpeg";
		}
		if (compareBytes([255, 255, 255, 255], [79, 103, 103, 83])) {
			return "video/ogg";
		}
		if (compareBytes([255, 255, 255, 255], [26, 69, 223, 163])) {
			return "video/webm";
		}
		if (compareBytes([0, 0, 0, 0, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 102, 116, 121, 112, 51, 103])) {
			return "video/3gpp";
		}
		if (isTransportStream()) {
			return "video/mp2t";
		}
	}
	if (expectedType == "audio") {
		if (compareBytes([255, 255], [255, 241]) || compareBytes([255, 255], [255, 249]) || compareBytes([255, 255], [255, 254])) {
			return "audio/aac";
		}
		if (compareBytes([255, 255, 255, 255], [77, 84, 104, 100])) {
			return "audio/midi";
		}
		if (compareBytes([255, 255, 255, 255], [0, 0, 1, 179]) || compareBytes([255, 255, 255, 255], [0, 0, 1, 186])) {
			return "audio/mpeg";
		}
		if (compareBytes([255, 255], [255, 251]) || compareBytes([255, 255], [255, 243]) || compareBytes([255, 255], [255, 242]) || compareBytes([255, 255, 255], [73, 68, 51])) {
			return "audio/mpeg";
		}
		if (compareBytes([255, 255, 255, 255], [79, 103, 103, 83])) {
			return "audio/ogg";
		}
		if (compareBytes([255, 255, 255, 255, 0, 0, 0, 0, 255, 255, 255, 255], [82, 73, 70, 70, 0, 0, 0, 0, 87, 65, 86, 69])) {
			return "audio/wav";
		}
		if (compareBytes([255, 255, 255, 255], [26, 69, 223, 163])) {
			return "audio/webm";
		}
		if (compareBytes([0, 0, 0, 0, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 102, 116, 121, 112, 51, 103])) {
			return "audio/3gpp";
		}
	}
	if (expectedType == "model") {
		if (compareBytes([255, 255, 255, 255], [103, 108, 84, 70])) {
			return "model/gltf-binary";
		}
		if (compareBytes([255, 255, 255, 255], [80, 75, 3, 4]) && isUSDZ()) {
			return "model/vnd.usdz+zip";
		}
	}

	function isUSDZ() {
		const value = new Uint8Array(buffer);
		if (value.length > ZIP_FILENAME_OFFSET) {
			const filenameLength = value[ZIP_FILENAME_LENGTH_OFFSET] | (value[ZIP_FILENAME_LENGTH_OFFSET + 1] << 8);
			if (value.length >= ZIP_FILENAME_OFFSET + filenameLength) {
				const filename = new TextDecoder().decode(value.subarray(ZIP_FILENAME_OFFSET, ZIP_FILENAME_OFFSET + filenameLength));
				return USD_FILENAME_REGEXP.test(filename);
			}
		}
		return false;
	}

	function isTransportStream() {
		const value = new Uint8Array(buffer);
		return value.length > TRANSPORT_STREAM_PACKET_SIZE * 2 &&
			value[0] == TRANSPORT_STREAM_SYNC_BYTE &&
			value[TRANSPORT_STREAM_PACKET_SIZE] == TRANSPORT_STREAM_SYNC_BYTE &&
			value[TRANSPORT_STREAM_PACKET_SIZE * 2] == TRANSPORT_STREAM_SYNC_BYTE;
	}

	function compareBytes(mask, pattern) {
		let patternMatch = true, index = 0;
		if (buffer.byteLength >= pattern.length) {
			const value = new Uint8Array(buffer, 0, mask.length);
			for (index = 0; index < mask.length && patternMatch; index++) {
				patternMatch = patternMatch && ((value[index] & mask[index]) == pattern[index]);
			}
			return patternMatch;
		}
	}
}

function log(...args) {
	console.log("S-File <browser>", ...args); // eslint-disable-line no-console
}