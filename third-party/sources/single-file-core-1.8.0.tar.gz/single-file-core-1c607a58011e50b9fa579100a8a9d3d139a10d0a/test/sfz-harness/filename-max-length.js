// formatFilename truncates an over-long filename to filenameMaxLength and then appends an ellipsis
// and the extension, but the budget it truncated to only ever subtracted the extension. The
// ellipsis was never counted, so every truncated filename came out over the limit — by one
// character in "char" mode, by the 3 bytes of U+2026 in "bytes" mode. Harmless at the default 192,
// but a user who sets the limit to the filesystem maximum of 255 gets 258 and the download is
// refused, which sends the save down the download-util.js retry ladder for no reason.
//
// The negative budget was worse than an overrun. truncateText slices a Blob, and Blob.slice reads a
// negative start as an offset from the END, so a limit smaller than the extension returned nearly
// the whole 800-byte filename instead of nothing.

// template-formatter.js reaches core/helper.js, which pulls in the frame hooks, and those install
// themselves against window and document as they are evaluated: the stubs go in before the import
globalThis.window = globalThis;
globalThis.document = {};
globalThis.Document = class Document { };
globalThis.MutationObserver = class MutationObserver { observe() { } };
const { formatFilename } = await import("../../modules/template-formatter.js");

const LONG_TITLE = "a".repeat(400);
const MULTIBYTE_TITLE = "é".repeat(400);

let failed = false;

function check(label, actual, expected) {
	const ok = actual === expected;
	console.log(`${ok ? "PASS" : "FAIL"} ${label}: ${actual}${ok ? "" : " (expected " + expected + ")"}`);
	failed ||= !ok;
}

async function format(filenameTemplate, filenameMaxLengthUnit, filenameMaxLength, formatOptions = {}) {
	return formatFilename("", null, {
		url: "https://example.com/page",
		filenameTemplate,
		filenameReplacementCharacter: "_",
		filenameReplacedCharacters: [],
		filenameReplacementCharacters: [],
		backgroundSave: true,
		filenameMaxLengthUnit,
		filenameMaxLength,
		...formatOptions
	});
}

async function getFilename(title, filenameMaxLengthUnit, filenameMaxLength) {
	return format(title + ".html", filenameMaxLengthUnit, filenameMaxLength);
}

async function getSize(title, unit, maxLength) {
	const filename = await getFilename(title, unit, maxLength);
	return unit == "bytes" ? new Blob([filename]).size : filename.length;
}

for (const maxLength of [192, 255]) {
	check(`ascii title, ${maxLength} bytes`, await getSize(LONG_TITLE, "bytes", maxLength) <= maxLength, true);
	check(`multibyte title, ${maxLength} bytes`, await getSize(MULTIBYTE_TITLE, "bytes", maxLength) <= maxLength, true);
	check(`ascii title, ${maxLength} chars`, await getSize(LONG_TITLE, "char", maxLength) <= maxLength, true);
	check(`multibyte title, ${maxLength} chars`, await getSize(MULTIBYTE_TITLE, "char", maxLength) <= maxLength, true);
}

// the extension and the ellipsis alone are longer than the limit, so the result cannot fit. What it
// must not do is grow: before the fix the byte case returned 812 bytes for a limit of 4
check("limit shorter than the extension keeps only the suffix", await getFilename(LONG_TITLE, "bytes", 4), "….html");
check("limit shorter than the extension, chars", await getFilename(LONG_TITLE, "char", 3), "….html");

// nothing above the limit is truncated at all, ellipsis included
check("a filename at the limit is left alone", await getFilename("a".repeat(187), "bytes", 192), "a".repeat(187) + ".html");

// #1995: the extension was re-derived from the truncated name with a regex matching ONE trailing
// segment of 3 or 4 characters, so ".u.zip.html" was cut down to ".html" and an archive stopped
// looking like one. The options say which extension was appended, so the whole chain is kept
const FORMATS = [
	[".html", {}],
	[".zip", { compressContent: true }],
	[".zip.html", { compressContent: true, selfExtractingArchive: true }],
	[".u.zip.html", { compressContent: true, selfExtractingArchive: true, extractDataFromPage: true }]
];

for (const [extension, formatOptions] of FORMATS) {
	for (const unit of ["bytes", "char"]) {
		const filename = await format(LONG_TITLE + extension, unit, 192, formatOptions);
		check(`${extension} survives the truncation, ${unit}`, filename.endsWith("…" + extension), true);
		check(`${extension} stays within the limit, ${unit}`, (unit == "bytes" ? new Blob([filename]).size : filename.length) <= 192, true);
	}
}

// a template that does not end with the extension of the chosen format falls back to the regex
check("a custom extension is kept", (await format(LONG_TITLE + ".htm", "bytes", 192, { compressContent: true })).endsWith("….htm"), true);

// #2037: the grammar names the unit "ch" and the formatter tested for "char", so "[Nch]" counted
// bytes like "[N]". A character is a code point, so a 4-byte letter counts as one, not two
const ASTRAL_TITLE = "\u{1D400}".repeat(200);
async function formatTitle(template, title) {
	return (await formatFilename("", null, {
		url: "https://example.com/page",
		title,
		filenameTemplate: template,
		filenameReplacementCharacter: "_",
		filenameReplacedCharacters: [],
		filenameReplacementCharacters: [],
		backgroundSave: true,
		filenameMaxLengthUnit: "chars",
		filenameMaxLength: 1024
	})).replace(/\.html$/, "");
}
check("[147] keeps 147 bytes of a 4-byte title", new Blob([await formatTitle("{page-title}[147].{filename-extension}", ASTRAL_TITLE)]).size, 144);
check("[147ch] keeps 147 characters of a 4-byte title", [...await formatTitle("{page-title}[147ch].{filename-extension}", ASTRAL_TITLE)].length, 147);
check("[10ch] keeps 10 characters of an ascii title", await formatTitle("{page-title}[10ch].{filename-extension}", LONG_TITLE), "a".repeat(10));
check("[10ch] on a function call", await formatTitle("%uppercase<{page-title}>[10ch].{filename-extension}", LONG_TITLE), "A".repeat(10));

if (failed) {
	console.log("FAILED");
	Deno.exit(1);
} else {
	console.log("PASSED");
}
