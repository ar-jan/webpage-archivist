# SFZ format harness

Tests for the SingleFile archive writer in `processors/compression/`, which drive
`process()` directly with synthetic page data, so they need no browser and no network.
The format itself is specified in [`doc/singlefile-archive.md`](../../doc/singlefile-archive.md).

The directory has since taken in suites for code the archive writer does not own — the
CSS processors, the download filename helpers — because they need the same Deno-with-a-
DOM-stub setup and there was nowhere else to put them. The table says which is which.

Run them with Deno, from the repository root:

```
npm test
```

which is [`test/run.js`](../run.js), the runner for every suite under `test/`. It takes
name filters, so this directory alone is:

```
deno run --allow-read --allow-run test/run.js sfz-harness
```

or one at a time, which needs no runner:

```
deno run --allow-read test/sfz-harness/format-rules.js
```

## The suites

CI runs these. Each prints one `PASS`/`FAIL` line per check and exits non-zero if
any check failed.

| Script | What it covers |
|---|---|
| `format-rules.js` | The rules of the format: the charset declaration and the doctype cap that keeps it inside the scan window, the wrapper-tag ladder and its selection tests, the identifier, appended-data placement and declaration, password scope, the PDF and PNG faces. |
| `stored-trigger.js` | That a stored (uncompressed) entry whose bytes contain a rung's pattern moves the writer to the right rung. |
| `check-determinism.js` | That the same inputs produce the same bytes, and that the levers which should change the output do. |
| `option-wiring.js` | That every option `compression.js` reads is either declared as a caller option or classified as internal, and that `single-file.js` still builds its argument from that declaration. Guards the layer the other suites sit below. |
| `css-property-filter.js` | That the declaration filter keeps a property css-tree's dictionary does not know (`stop-color`, `flood-opacity`, anything newer than the pinned build) and still drops a genuinely invalid value. |
| `adopted-stylesheets-hook.js` | That the page-world hook answers the adopted-stylesheets request for a CLOSED shadow root, which its host does not expose. |
| `inlined-functions.js` | That a function serialized into a self-extracting archive names nothing outside itself. An import survives bundling and still reads correctly, and the archive then throws a bare `ReferenceError` and renders nothing. |
| `pages-archive.js` | That `createPagesArchive` packs several pages into one archive correctly: the first page at the root and the others in folders, the manifest, the symlink a deduplicated entry leaves behind, and the escaping of crawled titles in both tables of contents. Also that the options reaching the archive writer are derived from `PROCESS_OPTION_NAMES` rather than hand-listed — a hand copy dropped `maxAppendedDataLength` for months — and that `password` stays out of that derivation, since forwarding it would make the writer withhold the prologue's title as if the archive were encrypted while the table of contents and every entry comment still rode in that same cleartext prologue. |
| `pages-router.js` | That the router opens a multi-page archive on the page a reader expects: the table of contents when the archive stores one, the first page when it does not, and the page a route in the hash names whatever else is stored. The router is inlined into the archive as source text and only ever ran inside a saved page, so nothing drove it before; the table of contents shipped stored, routable and unreachable. |
| `content-type-sniffing.js` | That a magic-byte match beats the `Content-Type` header, and that the header survives when nothing matches. science.org serves its woff2 files as `text/plain`, which used to be trusted, so the fonts were embedded as `data:text/plain` and the SFZ writer deflated a file that is already Brotli-compressed. Two cases guard the rules themselves rather than the outcome: a video whose first byte is `G` must not be relabelled `video/mp2t`, and the generic `mif1` HEIF brand must identify nothing, because an AVIF can carry it and calling it HEIC would name a format no browser decodes. |
| `jxl-resource.js` | That a JPEG XL image is named `.jxl` in the archive even when its URL carries no extension, and that the extractor hands a `.jxl` entry back as `image/jxl`. The sniffer knew the format, the two tables around it did not, so a JXL from an image CDN went in with no extension and came back as `application/octet-stream`. |
| `entry-compression.js` | That an entry is deflated or stored on the content type the server sent, not on the extension alone — a module served as `text/javascript` from a `.ts` URL used to go in uncompressed — and that an unrecognized `application/octet-stream` still stays stored. |
| `filename-max-length.js` | That `formatFilename` counts the ellipsis as well as the extension in the budget it truncates to, so a filename at `filenameMaxLength` stays at it, and that a limit shorter than the extension does not reach `Blob.slice` with a negative start. Also that `[Nch]` in a template keeps N characters, counted by code point, while `[N]` keeps N bytes (#2037: the unit was named `ch` by the grammar and tested as `char`, so both counted bytes). |
| `filename-entities.js` | That the page-text template variables (`page-title`, `page-heading`, `page-description`, `page-author`, `page-creator`, `page-publisher`) decode HTML character references a second time, so a site that escapes its title twice does not leave `&amp;` or `&#8217;` in the filename (#2036), while the URL variables keep their ampersands. |
| `filename-characters.js` | That `getValidFilename` maps a full-width lookalike one character at a time — `C++` used to be saved as `C＋` — while a run of characters with no lookalike still collapses to a single replacement. |
| `zip64.js` | That the `page.pdf` record injection accounts for the zip64 end of central directory record (§5.7): all four EOCD fields left at their sentinels, the entry counts and directory size carried in the zip64 record, the directory offset pointing at the injected record, and the archive still readable. The branch runs only past 4 GiB or 65535 entries, so nothing reached it before; the suite forces zip64 through `zipWriter.options` from inside the `writeEntries` callback, with no production lever. |
| `byte-map.js` | That the byte offsets §8.2 of the specification prints still describe what the writer emits: the prologue order, the doctype and root tag with nothing between them, the identifier's length ahead of the region, absolute EOCD offsets, and the entry order. The specimen §8.2 documents is saved from a live URL and has never been in this repository, so none of its numbers could be checked; three of them were wrong. This builds an equivalent with no network. |
| `relocation-cost.js` | That the figures §5.2 prints for relocating the extra-data element reconstruct. Two of the three came from live captures and did not: the paragraph subtracted the terminator and the end tags from the reservation without subtracting the element, which the appended placement carries too, so it over-counted by the whole element. This pins the corrected arithmetic — the cost is the reservation margin alone, it is positive on every rung whenever an element exists, and the only way relocation saves bytes is to have no element to relocate. |
| `charset-round-trip.js` | That the encoding tables §8.4 prints still describe the WHATWG index: which 20 of the 38 encodings carry all 256 byte values through a decode injectively, the sizes of the reverse tables they need, and the five windows-1252 positions a platform codec of the same name leaves undefined. It also re-derives the reverse table the extractor ships as a literal, which no build step checks and which corrupts one byte per occurrence when wrong. |
| `css-fonts-minifier.js` | That `removeUnusedFonts` reads the font families it prunes on correctly: a `var()` family resolved from the values the document declares and not only from the ones the body inherits, every font kept when the value is genuinely undetermined, and a multi-word family name that does not also claim a font named after its own tail. |
| `font-face-composite.js` | That several `@font-face` rules declaring the same family with the same style descriptors are one composite face and not a stack where the last rule wins, which is what CSS Fonts 4 §5.2 and §4.5.1 say: both members are kept with their own sources, faces split by `unicode-range` are all kept, an outright duplicate rule is emitted once, and a source repeated inside one rule is listed once, at the position of its later declaration. |

## The tools

Not tests — they print, they do not assert, and CI does not run them. The runner skips
them by name, in the `NOT_SUITES` list of [`test/run.js`](../run.js). Everything else in
this directory IS run, so a new file is either a suite or a line in that list.

| Script | Use |
|---|---|
| `smoke.js` | Build one archive and print its size, chosen rung and first 200 bytes. |
| `search-triggers.js` | Search seeds for page data that triggers a given condition. Its results are `trigger-seeds.json`. |
| `gen-e2e-page.js` | Write a page fixture to disk for end-to-end use. |

`common.js` builds the synthetic page data and options; `dom-stub.js` supplies the
minimum DOM the compression code touches, because Deno has no `DOMParser`. Import it
first — `compression.js` reads `globalThis.DOMParser` when it loads.

## Adding a test

Add checks to the suite that already covers the area, rather than creating a file per
rule. A check is one line:

```js
check("the label that appears in the output", actual, expected);
```

Two things are worth doing every time. Write the comment that says *why* the rule
exists, not what the code does — several rules here look arbitrary until you know which
tokenizer state or which reader made them necessary. And confirm the test can fail:
break the rule in `compression.js`, watch the check go red, then put it back. A check
that passes against a deliberately broken writer is protecting nothing, which is how
the case-insensitivity of the rung patterns went untested for as long as it did.
