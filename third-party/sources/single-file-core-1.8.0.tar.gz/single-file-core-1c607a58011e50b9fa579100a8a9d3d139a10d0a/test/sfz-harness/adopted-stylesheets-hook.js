/*
 * Copyright 2010-2026 Gildas Lormeau
 * contact : gildas.lormeau <at> gmail.com
 *
 * This file is part of SingleFile.
 *
 *   The code in this file is free software: you can redistribute it and/or
 *   modify it under the terms of the GNU Affero General Public License
 *   (GNU AGPL) as published by the Free Software Foundation, either version 3
 *   of the License, or (at your option) any later version.
 *
 *   The code in this file is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
 *   General Public License for more details.
 *
 *   As additional permission under GNU AGPL version 3 section 7, you may
 *   distribute UNMODIFIED VERSIONS OF THIS file without the copy of the GNU
 *   AGPL normally required by section 4, provided you include this license
 *   notice and a URL through which recipients can access the Corresponding
 *   Source.
 */

// A shadow root's constructed stylesheets cannot be read from the extension's own
// world, so the page-world hook reads them and answers a request event. It used to
// resolve the root with `event.target.shadowRoot`, which is null for a CLOSED root,
// and then answered nothing at all. The extension still captured the root's content,
// because it reaches closed roots through openOrClosedShadowRoot, so a closed root
// came back in the saved page with its markup intact and its styles gone, with no
// error anywhere. Measured on 2026-08-30 in Firefox and in Chrome, and again after
// the fix, with tmp/closed-shadow-root-probe.html.
//
// The hook now records every root as it is attached and falls back to that record.
// This test drives the hook's own listener over a stub of the one browser rule the
// bug turns on: attachShadow returns the root to its caller either way, and leaves
// host.shadowRoot null when the mode is closed.

const REQUEST_EVENT = "single-file-request-get-adopted-stylesheets";
const RESPONSE_EVENT = "single-file-response-get-adopted-stylesheets";
const UNREGISTER_EVENT = "single-file-unregister-request-get-adopted-stylesheets";
const CLEAR_EVENT = "single-file-clear-adopted-stylesheets-cache";
const HOOK_PATH = new URL("../../processors/hooks/content/content-hooks-frames-web.js", import.meta.url);

let failures = 0;

const documentListeners = new Map();
installStubs();
const originalAttachShadow = globalThis.Element.prototype.attachShadow;
new Function(await Deno.readTextFile(HOOK_PATH))();
const listener = documentListeners.get(REQUEST_EVENT);

check("the hook registers a listener for the request event", Boolean(listener));
check("the hook patches attachShadow", globalThis.Element.prototype.attachShadow !== originalAttachShadow);
check("the patched attachShadow still looks native",
	globalThis.Element.prototype.attachShadow.toString() === "function attachShadow() { [native code] }" &&
	globalThis.Element.prototype.attachShadow.name === "attachShadow");

// an open root: the host exposes it, which is the path that always worked
const openHost = new StubElement();
const openRoot = openHost.attachShadow({ mode: "open" });
adopt(openRoot, ".open { color: red }");
check("attachShadow returns the root for an open mode", openRoot instanceof StubShadowRoot);
check("an open root answers with its stylesheets",
	sameStrings(request(openHost, openRoot), [".open { color: red }"]));

// a closed root: the host exposes nothing, so only the record can resolve it
const closedHost = new StubElement();
const closedRoot = closedHost.attachShadow({ mode: "closed" });
adopt(closedRoot, ".closed { color: blue }");
check("a closed root is hidden from its host", closedHost.shadowRoot === null);
check("attachShadow returns the root for a closed mode", closedRoot instanceof StubShadowRoot);
check("a closed root answers with its stylesheets",
	sameStrings(request(closedHost, closedRoot), [".closed { color: blue }"]));

// the same, for a sheet the page never passed through replaceSync, so that the
// answer comes from cssRules rather than from the recorded text
const rulesHost = new StubElement();
const rulesRoot = rulesHost.attachShadow({ mode: "closed" });
rulesRoot.adoptedStyleSheets = [{ cssRules: [{ cssText: ".rules { color: green }" }] }];
check("a closed root answers from cssRules when the text was not recorded",
	sameStrings(request(rulesHost, rulesRoot), [".rules { color: green }"]));

// an empty root still registers the hook's listener on itself, which is what lets a
// NESTED host inside it be reached later; only the answer is withheld
const emptyHost = new StubElement();
const emptyRoot = emptyHost.attachShadow({ mode: "closed" });
check("an empty root answers nothing", request(emptyHost, emptyRoot) === undefined);
check("an empty root is still listened to for nested hosts", emptyRoot.listenerCount(REQUEST_EVENT) > 0);

// a target that is neither a host nor a recorded root must not throw
check("an unrelated target is ignored", request(new StubElement(), new StubShadowRoot()) === undefined);

// the cleanup the hook installs on each root it answers for. Both halves of it were dead:
// the unregister handler was a fresh closure per handshake, so it was never the no-op that
// re-adding a registered listener is and one was left behind per root per save, and it
// removed the request listener without the capture flag it had been added with, which
// matches nothing at all
const repeatHost = new StubElement();
const repeatRoot = repeatHost.attachShadow({ mode: "open" });
adopt(repeatRoot, ".repeat { color: teal }");
request(repeatHost, repeatRoot);
const unregisterAfterFirst = repeatRoot.listenerCount(UNREGISTER_EVENT);
request(repeatHost, repeatRoot);
request(repeatHost, repeatRoot);
check("one handshake installs one unregister listener", unregisterAfterFirst === 1);
check("repeated handshakes do not accumulate unregister listeners",
	repeatRoot.listenerCount(UNREGISTER_EVENT) === 1);
check("the root is listened to for requests until it is unregistered",
	repeatRoot.listenerCount(REQUEST_EVENT) === 1);
repeatRoot.dispatchEvent(new globalThis.CustomEvent(UNREGISTER_EVENT, { bubbles: true }));
check("unregistering removes the request listener the hook added with capture",
	repeatRoot.listenerCount(REQUEST_EVENT) === 0);
check("the unregister listener removes itself once it has fired",
	repeatRoot.listenerCount(UNREGISTER_EVENT) === 0);

// A sheet the page never passed through replaceSync has to be serialised from cssRules, and that
// used to happen once per adopting root: instrumenting a reddit capture counted 499 roots asking
// for 643 adoptions of 42 distinct sheets. The serialisation is memoised in a map of its own, next
// to the recorded text, so the walk happens once however many roots adopt the sheet.
const sharedSheet = new globalThis.CSSStyleSheet();
sharedSheet.insertRule(".shared { color: olive }");
const firstHost = new StubElement();
const firstRoot = firstHost.attachShadow({ mode: "closed" });
firstRoot.adoptedStyleSheets = [sharedSheet];
const secondHost = new StubElement();
const secondRoot = secondHost.attachShadow({ mode: "closed" });
secondRoot.adoptedStyleSheets = [sharedSheet];
const readsBeforeSharing = globalThis.CSSStyleSheet.reads;
const firstAnswer = request(firstHost, firstRoot);
const secondAnswer = request(secondHost, secondRoot);
check("a sheet with no recorded text is walked once for two roots",
	globalThis.CSSStyleSheet.reads - readsBeforeSharing === 1);
check("and both roots are answered with its rules",
	sameStrings(firstAnswer, [".shared { color: olive }"]) && sameStrings(secondAnswer, [".shared { color: olive }"]));

// the memo must not outlive the sheet it describes: insertRule and deleteRule already drop the
// recorded text, and dropping the memo with it is what keeps a mutated sheet from being answered
// with what it used to say
sharedSheet.insertRule(".added { color: navy }");
const readsBeforeMutation = globalThis.CSSStyleSheet.reads;
const answerAfterMutation = request(firstHost, firstRoot);
check("mutating the sheet makes the next request walk it again",
	globalThis.CSSStyleSheet.reads - readsBeforeMutation === 1);
check("and the answer carries the added rule",
	sameStrings(answerAfterMutation, [".shared { color: olive }\n.added { color: navy }"]));

// A page can also change a sheet through the CSSOM, through a rule's style or a grouping rule's own
// insertRule, which the hook cannot see. The memo therefore lasts one capture: the capture clears it
// before it walks the page, so a later save reads what the sheet says then rather than what the
// first save serialised. Measured in the field as the first save's text served on every later save
// of the same tab. The text recorded by replaceSync is kept, it is the author's source and no walk
// reproduces it.
const clearListener = documentListeners.get(CLEAR_EVENT);
check("the hook listens for the clear event on the document", Boolean(clearListener));
sharedSheet.editRule(1, ".added { color: maroon }");
const readsBeforeEdit = globalThis.CSSStyleSheet.reads;
check("an edit through the CSSOM is served from the memo within a capture",
	sameStrings(request(firstHost, firstRoot), [".shared { color: olive }\n.added { color: navy }"]) &&
	globalThis.CSSStyleSheet.reads - readsBeforeEdit === 0);
if (clearListener) {
	clearListener(new globalThis.CustomEvent(CLEAR_EVENT));
}
const readsBeforeClear = globalThis.CSSStyleSheet.reads;
check("clearing the cache makes the next capture walk the sheet again",
	sameStrings(request(firstHost, firstRoot), [".shared { color: olive }\n.added { color: maroon }"]) &&
	globalThis.CSSStyleSheet.reads - readsBeforeClear === 1);
const readsBeforeRecorded = globalThis.CSSStyleSheet.reads;
check("and the text recorded by replaceSync survives the clear",
	sameStrings(request(openHost, openRoot), [".open { color: red }"]) &&
	globalThis.CSSStyleSheet.reads - readsBeforeRecorded === 0);

console.log(failures ? `\n${failures} check(s) FAILED` : "\nall checks passed");
Deno.exit(failures ? 1 : 0);

function request(target, listeningRoot) {
	let answer;
	const responseListener = event => answer = event.detail.adoptedStyleSheets;
	listeningRoot.addEventListener(RESPONSE_EVENT, responseListener);
	listener({ target, stopPropagation() { } });
	listeningRoot.removeEventListener(RESPONSE_EVENT, responseListener);
	return answer;
}

function adopt(root, text) {
	const sheet = new globalThis.CSSStyleSheet();
	sheet.replaceSync(text);
	root.adoptedStyleSheets = [sheet];
}

function sameStrings(value, expected) {
	return Array.isArray(value) && value.length === expected.length && value.every((item, index) => item === expected[index]);
}

function check(label, condition) {
	if (!condition) {
		failures++;
	}
	console.log((condition ? "PASS" : "FAIL") + " " + label);
}

// the stub below models only what the hook touches while it installs itself and
// while it answers one request; it is deliberately not a DOM
function StubShadowRoot() {
	this.adoptedStyleSheets = [];
	this.listeners = new Map();
}

function StubElement() {
	this.shadowRoot = null;
	this.listeners = new Map();
}

function installStubs() {
	// a listener is identified by type, callback AND capture: adding one that is already
	// registered is a no-op, and removing one with a different capture flag matches nothing.
	// The stub has to model both, because those are the two rules the cleanup code got wrong
	const listenerMethods = {
		addEventListener(type, listener, options) {
			const capture = Boolean(options && options.capture);
			if (!this.listeners.has(type)) {
				this.listeners.set(type, []);
			}
			const listeners = this.listeners.get(type);
			if (!listeners.some(entry => entry.listener === listener && entry.capture === capture)) {
				listeners.push({ listener, capture, once: Boolean(options && options.once) });
			}
		},
		removeEventListener(type, listener, options) {
			const capture = Boolean(options && options.capture);
			const listeners = this.listeners.get(type) || [];
			const index = listeners.findIndex(entry => entry.listener === listener && entry.capture === capture);
			if (index !== -1) {
				listeners.splice(index, 1);
			}
		},
		dispatchEvent(event) {
			event.currentTarget = this;
			(this.listeners.get(event.type) || []).slice().forEach(entry => {
				if (entry.once) {
					this.removeEventListener(event.type, entry.listener, { capture: entry.capture });
				}
				entry.listener(event);
			});
			event.currentTarget = null;
			return true;
		},
		listenerCount(type) {
			return (this.listeners.get(type) || []).length;
		}
	};
	Object.assign(StubShadowRoot.prototype, listenerMethods);
	Object.assign(StubElement.prototype, listenerMethods);

	// the rule the bug turns on: the caller gets the root whatever the mode, while the
	// host exposes it only when the mode is open
	StubElement.prototype.attachShadow = function (init) {
		const shadowRoot = new StubShadowRoot();
		shadowRoot.host = this;
		this.shadowRoot = init && init.mode === "closed" ? null : shadowRoot;
		return shadowRoot;
	};

	// cssRules counts its reads, because "serialised once" is a statement about how often the hook
	// walks it, and insertRule exists so the hook's own invalidation can be exercised
	const sheetRules = new WeakMap();
	class StubCSSStyleSheet {
		replaceSync(text) {
			sheetRules.set(this, [text]);
		}
		insertRule(rule) {
			sheetRules.set(this, (sheetRules.get(this) || []).concat(rule));
		}
		// a CSSOM edit the hook does not patch, such as a rule's style being set
		editRule(index, cssText) {
			sheetRules.get(this)[index] = cssText;
		}
		get cssRules() {
			StubCSSStyleSheet.reads++;
			return (sheetRules.get(this) || []).map(cssText => ({ cssText }));
		}
	}
	StubCSSStyleSheet.reads = 0;

	globalThis.Element = StubElement;
	globalThis.CSSStyleSheet = StubCSSStyleSheet;
	globalThis.CustomEvent = class CustomEvent {
		constructor(type, init = {}) {
			this.type = type;
			this.detail = init.detail;
			this.bubbles = Boolean(init.bubbles);
		}
	};
	globalThis.Event = class Event { constructor(type) { this.type = type; } };
	globalThis.UIEvent = globalThis.Event;
	globalThis.screen = { width: 0, height: 0 };
	globalThis.MutationObserver = class MutationObserver { observe() { } };
	globalThis.fetch = () => Promise.reject(new Error("the hook test makes no request"));
	globalThis.document = {
		addEventListener(type, listener) {
			documentListeners.set(type, listener);
		},
		removeEventListener() { },
		dispatchEvent() { return true; },
		querySelectorAll: () => [],
		documentElement: {},
		fonts: { add() { }, delete() { }, clear() { }, forEach() { } }
	};
}
